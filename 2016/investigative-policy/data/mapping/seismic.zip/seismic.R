# load required packages
library(rgdal)
library(rgeos)
library(kwgeo)
library(raster)

# read and reproject central and eastern us
ce <- readOGR("CEUS_ProbDamageAvg","CEUS_ProbDamageAvg")
ce <- spTransform(ce, CRS( "+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0" ) ) 
ce@proj4string

# read and reproject western us
w <- readOGR("WUS_ProbDamageAvg","WUS_ProbDamageAvg")
w <- spTransform(w, CRS( "+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0" ) ) 
w@proj4string

# combine
us <- aggregate(w, ce, makeUniqueIDs = TRUE)  

# import world countries 
countries <- readOGR("ne_50m_admin_0_countries_lakes", "ne_50m_admin_0_countries_lakes")
countries@proj4string

# select just US as clip layer
clip <- countries [which(countries@data$name == "United States"),]

# clip
us_clip <- us[clip, ]

# set carto account details
cartodb_id <- "peter-aldhous"
cartodb_api <- "4e0413e60d653cdd010fbfd6a3f233e50099bbd1"

# upload to carto
r2cartodb(us_clip, "seismic", cartodb_id, cartodb_api)


